# Sudoku Treasure Hunt Puzzle

This repository hosts a Sudoku puzzle for a treasure hunt.

## How to Use

1. Go to the GitHub Pages URL after enabling Pages on this repo.
2. Students scan the QR code pointing to that URL.
3. They solve the Sudoku puzzle.
4. When solved correctly, the hidden clue will appear.

## Hosting

- Push this repo to GitHub.
- Enable GitHub Pages (Settings → Pages → Source = main branch / root).
- The puzzle will be live at: https://<your-username>.github.io/<repo-name>/
